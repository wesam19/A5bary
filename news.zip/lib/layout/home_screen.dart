import 'package:flutter/material.dart';
import '../models/sources_response.dart';
import 'package:apinew/screens/home.dart';
import'package:apinew/ApiManager.dart';

import '../models/category.dart';
import '../screens/categories.dart';
import '../screens/drawer_widget.dart';
import 'package:apinew/search.dart';
class HomeLayout extends StatefulWidget {
  static const String routeName = 'Home';

  @override
  State<HomeLayout> createState() => _HomeLayoutState();
}

class _HomeLayoutState extends State<HomeLayout> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
          color: Colors.white,
          image: DecorationImage(
              image: AssetImage(
                'C:/Users/Esraa/StudioProjects/apiNew/assest/pattern.png',
              ),
              fit: BoxFit.cover)),
      child: Scaffold(
        appBar: AppBar(
          elevation: 0.0,
          title: const Text('News'),
          shape: const OutlineInputBorder(
              borderSide: BorderSide(color: Colors.transparent),
              borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(12),
                  bottomLeft: Radius.circular(12))),
          actions: [
            selectedCategory!=null? InkWell(
              onTap: (){
                Navigator.pushNamed(context, search.routeName);
              },
              child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12.0),
                child: Icon(Icons.search,size: 28,),
              ),
            ) :SizedBox(
              height: 10,
            ),
          ],
        ),
        backgroundColor: Colors.transparent,
        body: selectedCategory==null?
        CategoriesScreen(selectedCategoryItem)
            :HomeScreen(selectedCategory!),

        drawer: DrawerWidget(onDrawerClicked),
      ),
    );
  }

  Category? selectedCategory=null;

  void onDrawerClicked(number){
    if(number==DrawerWidget.CATEGORY){
      selectedCategory=null;
      setState(() {
        Navigator.pop(context);
      });
    }else if(number==DrawerWidget.SETTINGS){
      // open settings screen
    }
  }


  void selectedCategoryItem(category){
    selectedCategory=category;
    setState(() {

    });
  }
}