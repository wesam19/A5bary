import 'package:flutter/material.dart';
import 'package:apinew/screens/tab_controller.dart';

import '../models/sources_response.dart';
import '../models/category.dart';
import 'package:apinew/local_db.dart';
import 'package:apinew/remote_api.dart';
import'package:apinew/ApiManager.dart';
import 'package:apinew/repository.dart';
class HomeScreen extends StatelessWidget {

  Category category;
  HomeScreen(this.category);

  ApiManager apiManager=ApiManager(baseRepository: RemoteApi());

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<SourcesResponse>(
      future: apiManager.baseRepository!.getSources(category.id),
      //future:ApiManager.getSources(category.id) ,
      builder: (context, snapshot) {
        if(snapshot.connectionState==ConnectionState.waiting){
          return Center(child: CircularProgressIndicator());
        }
        if(snapshot.hasError){
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Something went wrong'),
                TextButton(onPressed: (){}, child: Text('Try Again'))
              ],
            ),
          );
        }
        if(snapshot.data!.status !='ok'){
          return Column(
            children: [
              Text(snapshot.data?.message??""),
              TextButton(onPressed: (){}, child: Text('Try Again'))
            ],
          );
        }

        var sources=snapshot.data!.sources;
        return TabControllerScreen(sources??[]);
      },);
  }
 }