import 'package:apinew/models/sources_response.dart';
class NewsDataModel {
  NewsDataModel({
    this.status,
    this.code,
    this.message,
    this.totalResults,
    this.articles,
  });

  NewsDataModel.fromJson(dynamic json) {
    status = json['status'];
    code = json['code'];
    message = json['message'];
    totalResults = json['totalResults'];
    if (json['articles'] != null) {
      articles = [];
      json['articles'].forEach((v) {
        articles?.add(Articles.fromJson(v));
      });
    }
  }

  String? status;
  String? code;
  String? message;
  num? totalResults;
  List<Articles>? articles;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = status;
    map['totalResults'] = totalResults;
    if (articles != null) {
      map['articles'] = articles?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

/// source : {"id":"abc-news","name":"ABC News"}
/// author : "Rachel Bristol"
/// title : "Meet the Cast Member Behind Disney’s New Hanukkah Merchandise Collection"
/// description : "I grew up celebrating Hanukkah with my mom. Each year, she would set up a multi-colored felt candle menorah for us kids. Since we were too young to use a match or lighter, we’d spend each night of Hanukkah lighting the menorah with our felt flames. Then we’d …"
/// url : "https://disneyparks.disney.go.com/blog/2022/12/meet-the-cast-member-behind-disneys-new-hanukkah-merchandise-collection/"
/// urlToImage : "https://cdn1.parksmedia.wdprapps.disney.com/media/blog/wp-content/uploads/2022/12/guuhijfoias9et48uyu6i4twoe9fsd87yt.png"
/// publishedAt : "2022-12-21T18:30:02Z"
/// content : "I grew up celebrating Hanukkah with my mom. Each year, she would set up a multi-colored felt candle menorah for us kids. Since we were too young to use a match or lighter, wed spend each night of Han… [+2055 chars]"
class Articles {
  Articles({
    this.source,
    this.author,
    this.title,
    this.description,
    this.url,
    this.urlToImage,
    this.publishedAt,
    this.content,
  });

  Articles.fromJson(dynamic json) {
    source = json['source'] != null ? Sources.fromJson(json['source']) : null;
    author = json['author'];
    title = json['title'];
    description = json['description'];
    url = json['url'];
    urlToImage = json['urlToImage'];
    publishedAt = json['publishedAt'];
    content = json['content'];
  }

  Sources? source;
  String? author;
  String? title;
  String? description;
  String? url;
  String? urlToImage;
  String? publishedAt;
  String? content;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (source != null) {
      map['source'] = source?.toJson();
    }
    map['author'] = author;
    map['title'] = title;
    map['description'] = description;
    map['url'] = url;
    map['urlToImage'] = urlToImage;
    map['publishedAt'] = publishedAt;
    map['content'] = content;
    return map;
  }
}