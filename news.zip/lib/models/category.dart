import 'package:flutter/material.dart';

class Category {
  String id;
  String title;
  String image;
  Color color;

  Category(this.id, this.title, this.image, this.color);

  static List<Category> getCategories() {
    return [
      Category('general', 'General', 'C:/Users/Esraa/StudioProjects/apiNew/assest/environment.png',
          Color(0xFF4882CF)),
      Category(
          'health', 'Health', 'C:/Users/Esraa/StudioProjects/apiNew/assest/health.png',
          Color(0xFFED1E79)),
      Category(
          'sports', 'Sports', 'C:/Users/Esraa/StudioProjects/apiNew/assest/sports.png', Color(0xFFC91C22)),
      Category('business', 'Business', 'C:/Users/Esraa/StudioProjects/apiNew/assest/bussines.png',
          Color(0xFFCF7E48)),
      Category('entertainment', 'Entertainment',
          'C:/Users/Esraa/StudioProjects/apiNew/assest/science .png',
          Color(0xFF003E90)),
      Category(
          'science', 'Science',
          'C:/Users/Esraa/StudioProjects/apiNew/assest/science .png', Color(0xFFF2D352)),
      Category('technology', 'Technology', 'C:/Users/Esraa/StudioProjects/apiNew/assest/Politics.png',
          Color(0xFFED1E79)),

    ];
  }
}